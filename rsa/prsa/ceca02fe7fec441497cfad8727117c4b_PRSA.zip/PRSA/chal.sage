R.<x> = GF(2)[]

def bytes_to_poly(data):
    b_val = int.from_bytes(data, 'big')
    bits = [(b_val >> i) & 1 for i in range(b_val.bit_length())]
    return R(bits)

def get_random_irreducible(deg):
    while True:
        p = R.random_element(degree=deg)
        if p.degree() == deg and p.is_irreducible():
            return p

E = 0x10001
FLAG = b"FLAG{TEST_ME}"



Px = get_random_irreducible(1023)
Qx = get_random_irreducible(1025)
Nx = Px * Qx



Mx = bytes_to_poly(FLAG)
Cx = pow(Mx, E, Nx)
print(f"{Nx=}\n{Cx=}")
